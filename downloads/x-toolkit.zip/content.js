// content.js — รันบนหน้า x.com / twitter.com
// โหมด Unfollow: หาปุ่ม Following แล้ว unfollow
// โหมด Follow: หาปุ่ม Follow แล้วกดติดตามตามเงื่อนไข (verified / keyword bio / ผู้ติดตามขั้นต่ำ)

(() => {
  if (window.__xUnfollowToolLoaded) return;
  window.__xUnfollowToolLoaded = true;

  const HOUR = 3600 * 1000;
  const DAY = 24 * HOUR;
  const PROBE_MARK = "xuf_probe";

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

  // แปลงตัวเลขแบบ "1,234" / "12.3K" / "1.2M" เป็นจำนวนเต็ม
  function parseCount(text) {
    if (!text) return null;
    const m = String(text).replace(/,/g, "").match(/([\d.]+)\s*([KMB])?/i);
    if (!m) return null;
    let n = parseFloat(m[1]);
    if (isNaN(n)) return null;
    const suf = (m[2] || "").toUpperCase();
    if (suf === "K") n *= 1e3;
    else if (suf === "M") n *= 1e6;
    else if (suf === "B") n *= 1e9;
    return Math.round(n);
  }

  // ===== โหมด PROBE: แท็บที่เปิดมาเพื่ออ่านจำนวนผู้ติดตาม (+ อาจกดติดตาม) =====
  if (location.hash.includes(PROBE_MARK)) {
    // hash รูปแบบ #xuf_probe_follow_<N> = อ่านผู้ติดตาม แล้วถ้า >= N ให้กดติดตามบนโปรไฟล์นี้
    const fm = location.hash.match(/xuf_probe_follow_(\d+)/);
    const followThreshold = fm ? parseInt(fm[1], 10) : null;

    async function readFollowers() {
      const start = Date.now();
      while (Date.now() - start < 8000) {
        const link =
          document.querySelector('a[href$="/verified_followers"]') ||
          document.querySelector('a[href$="/followers"]');
        if (link) {
          const titled = link.querySelector("span[title]");
          const n = parseCount(titled ? titled.getAttribute("title") : link.textContent);
          if (n != null) return n;
        }
        await sleep(300);
      }
      return null;
    }

    // กดติดตามปุ่มของ "เจ้าของโปรไฟล์นี้" โดยเทียบ @handle จาก URL
    async function followOwner() {
      const handle = location.pathname.replace(/^\//, "").split("/")[0].toLowerCase();
      const start = Date.now();
      while (Date.now() - start < 6000) {
        // ถ้ามีปุ่ม unfollow ของคนนี้แสดงว่าติดตามอยู่แล้ว
        const unf = document.querySelector('button[data-testid$="-unfollow"]');
        if (unf && (unf.getAttribute("aria-label") || "").toLowerCase().includes("@" + handle)) {
          return false;
        }
        const btns = document.querySelectorAll('button[data-testid$="-follow"]');
        for (const b of btns) {
          const al = (b.getAttribute("aria-label") || "").toLowerCase();
          const r = b.getBoundingClientRect();
          if (r.width > 0 && al.includes("@" + handle)) {
            b.click();
            await sleep(800);
            return true;
          }
        }
        await sleep(300);
      }
      return false;
    }

    (async () => {
      const followers = await readFollowers();
      let followed = false;
      if (followThreshold != null && followers != null && followers >= followThreshold) {
        followed = await followOwner();
      }
      try {
        chrome.runtime.sendMessage({ type: "PROBE_RESULT", followers, followed });
      } catch (e) {
        /* background อาจปิดไปแล้ว */
      }
    })();
    return; // ไม่ลงทะเบียน loop ใด ๆ ในแท็บ probe
  }

  let running = false;
  let stopRequested = false;

  // ===== สถานะแยกตามแท็บ + ลิมิตรวมศูนย์ที่ background =====
  let myTabId = null;
  let myState = { running: false, mode: null, count: 0, lastUser: "", statusMsg: "" };

  async function ensureTabId() {
    if (myTabId != null) return myTabId;
    try {
      const r = await chrome.runtime.sendMessage({ type: "GET_TAB_ID" });
      myTabId = r && r.tabId != null ? r.tabId : null;
    } catch (e) {
      /* ignore */
    }
    return myTabId;
  }

  // เขียนสถานะของแท็บนี้ลง key เฉพาะแท็บ (xufState_<tabId>) → ไม่ชนกับแท็บอื่น
  async function writeState(patch) {
    Object.assign(myState, patch);
    await ensureTabId();
    if (myTabId != null) {
      await chrome.storage.local.set({ ["xufState_" + myTabId]: myState });
    }
  }

  // ตรวจลิมิตรวม (ทุกแท็บใช้ประวัติก้อนเดียวกันที่ background → กัน race)
  async function checkLimit(hourlyLimit, dailyLimit) {
    try {
      return await chrome.runtime.sendMessage({ type: "CHECK_LIMIT", hourlyLimit, dailyLimit });
    } catch (e) {
      return { within: true, reason: "" };
    }
  }

  async function recordAction() {
    try {
      await chrome.runtime.sendMessage({ type: "RECORD_ACTION" });
    } catch (e) {
      /* ignore */
    }
  }

  function isOnFollowingPage() {
    return /\/following\/?$/.test(location.pathname);
  }

  function getHandleFromCell(cell) {
    if (!cell) return "";
    const links = cell.querySelectorAll('a[href^="/"]');
    for (const a of links) {
      const href = a.getAttribute("href");
      if (/^\/[A-Za-z0-9_]+$/.test(href)) return href.slice(1);
    }
    return "";
  }

  function cellFollowsYou(cell) {
    if (!cell) return false;
    if (cell.querySelector('[data-testid="userFollowIndicator"]')) return true;
    const txt = cell.textContent || "";
    return /Follows you/i.test(txt) || txt.includes("ติดตามคุณอยู่");
  }

  function cellIsVerified(cell) {
    if (!cell) return false;
    return !!cell.querySelector('svg[data-testid="icon-verified"]');
  }

  function cellMatchesKeyword(cell, keywords) {
    if (!keywords || keywords.length === 0) return true;
    const txt = (cell.textContent || "").toLowerCase();
    return keywords.some((k) => txt.includes(k));
  }

  async function waitForConfirmButton(timeout = 4000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const confirm = document.querySelector('[data-testid="confirmationSheetConfirm"]');
      if (confirm) return confirm;
      await sleep(120);
    }
    return null;
  }

  async function scrollToLoadMore() {
    const before = document.documentElement.scrollHeight;
    window.scrollBy(0, window.innerHeight * 0.9);
    await sleep(1500);
    return document.documentElement.scrollHeight > before;
  }

  async function setStatus(msg) {
    await writeState({ statusMsg: msg });
  }

  // ===== ค้นปุ่มตามโหมด =====
  // โหมด unfollow: ปุ่ม data-testid ลงท้าย -unfollow
  function findNextUnfollow(opts, skipped) {
    const buttons = document.querySelectorAll('button[data-testid$="-unfollow"]');
    for (const btn of buttons) {
      const r = btn.getBoundingClientRect();
      if (r.width === 0 && r.height === 0) continue;
      const cell = btn.closest('[data-testid="UserCell"]') || btn.closest("article");
      const handle = getHandleFromCell(cell);
      if (handle && skipped.has(handle.toLowerCase())) continue;
      if (handle && opts.whitelist.includes(handle.toLowerCase())) continue;
      if (opts.nonMutualOnly && cellFollowsYou(cell)) continue;
      return { btn, handle, display: handle ? "@" + handle : "(ไม่ทราบ)" };
    }
    return null;
  }

  // โหมด follow: ปุ่ม data-testid ลงท้าย -follow (ไม่ใช่ -unfollow)
  function findNextFollow(opts, skipped) {
    const buttons = document.querySelectorAll('button[data-testid$="-follow"]');
    for (const btn of buttons) {
      const r = btn.getBoundingClientRect();
      if (r.width === 0 && r.height === 0) continue;
      const cell = btn.closest('[data-testid="UserCell"]') || btn.closest("article");
      const handle = getHandleFromCell(cell);
      if (handle && skipped.has(handle.toLowerCase())) continue;
      // ตัวกรองเร็ว (อ่านจากการ์ด)
      if (opts.verifiedOnly && !cellIsVerified(cell)) continue;
      if (!cellMatchesKeyword(cell, opts.bioKeywords)) continue;
      return { btn, handle, display: handle ? "@" + handle : "(ไม่ทราบ)" };
    }
    return null;
  }

  async function clickFollowButton(btn) {
    btn.scrollIntoView({ block: "center", behavior: "smooth" });
    await sleep(rand(250, 600));
    btn.click();
    // การกด Follow ไม่มี dialog ยืนยัน
    await sleep(rand(200, 400));
    return true;
  }

  async function clickUnfollowButton(btn) {
    btn.scrollIntoView({ block: "center", behavior: "smooth" });
    await sleep(rand(250, 600));
    btn.click();
    const confirm = await waitForConfirmButton();
    if (confirm) {
      await sleep(rand(200, 500));
      confirm.click();
    }
    return true;
  }

  // ขอข้อมูลจาก background (เปิดโปรไฟล์ทีละคน)
  // followThreshold != null → ให้ probe กดติดตามด้วยถ้าผู้ติดตามถึงเกณฑ์
  async function probeAuthor(handle, followThreshold) {
    try {
      const resp = await chrome.runtime.sendMessage({
        type: "PROBE_FOLLOWERS",
        handle,
        followThreshold,
      });
      return resp || { followers: null, followed: false };
    } catch (e) {
      return { followers: null, followed: false };
    }
  }

  // ===== โหมด FEED: รีโพสต์โพสต์ยอดดูสูง + ติดตามเจ้าของที่ผู้ติดตามเยอะ =====
  function waitForSelector(selector, timeout = 3000) {
    return new Promise(async (resolve) => {
      const start = Date.now();
      while (Date.now() - start < timeout) {
        const el = document.querySelector(selector);
        if (el) return resolve(el);
        await sleep(120);
      }
      resolve(null);
    });
  }

  function getPostKey(article) {
    const link = article.querySelector('a[href*="/status/"]');
    if (link) {
      const m = link.getAttribute("href").match(/\/status\/(\d+)/);
      if (m) return m[1];
    }
    return null;
  }

  function getAuthorHandle(article) {
    const nameBlock = article.querySelector('[data-testid="User-Name"]');
    return getHandleFromCell(nameBlock || article);
  }

  // ดึงตัวเลข metric จาก aria-label โดยจับ "เลข + คำสำคัญ"
  function metricFromLabel(label, patterns) {
    for (const p of patterns) {
      const m = label.match(new RegExp("([\\d.,]+\\s*[KMB]?)\\s*" + p, "i"));
      if (m) return parseCount(m[1]);
    }
    return null;
  }

  // อ่าน comments / likes / views จาก aria-label ของแถบ action (รวมทุก metric)
  function getMetrics(article) {
    const group = article.querySelector('[role="group"][aria-label]');
    const label = group ? group.getAttribute("aria-label") || "" : "";
    let views = metricFromLabel(label, ["views?", "การดู", "ดู"]);
    // fallback: ลิงก์ analytics (มี aria-label/ข้อความเป็นยอดดู)
    if (views == null) {
      const a = article.querySelector('a[href$="/analytics"]');
      if (a) {
        views =
          metricFromLabel(a.getAttribute("aria-label") || "", ["views?", "การดู", "ดู"]);
        if (views == null) views = parseCount(a.textContent);
      }
    }
    return {
      comments: metricFromLabel(label, ["repl(?:y|ies)", "การตอบกลับ", "ตอบกลับ", "ความคิดเห็น"]),
      likes: metricFromLabel(label, ["likes?", "ถูกใจ"]),
      views,
    };
  }

  function getViews(article) {
    return getMetrics(article).views;
  }

  // โพสต์นี้มีวิดีโอไหม (วิดีโอจริง / GIF / player)
  function articleHasVideo(article) {
    return !!article.querySelector(
      '[data-testid="videoPlayer"], [data-testid="videoComponent"], video'
    );
  }

  // เราติดตามเจ้าของโพสต์นี้อยู่ไหม (ดูจากปุ่มในโพสต์ — ไม่ต้องเปิดโปรไฟล์)
  // มีปุ่ม Follow = ยังไม่ติดตาม | มีปุ่ม Following/Unfollow หรือไม่มีปุ่มเลย = ติดตามอยู่
  function authorIsFollowed(article) {
    if (article.querySelector('button[data-testid$="-unfollow"]')) return true;
    if (article.querySelector('button[data-testid$="-follow"]')) return false;
    return true; // ไม่มีปุ่ม follow ในโพสต์ = ปกติของคนที่เราติดตามอยู่แล้ว
  }

  function findNextPost(processed) {
    const articles = document.querySelectorAll(
      'article[data-testid="tweet"], article[role="article"]'
    );
    for (const art of articles) {
      const r = art.getBoundingClientRect();
      if (r.width === 0 && r.height === 0) continue;
      const key = getPostKey(art);
      if (!key || processed.has(key)) continue;
      return { art, key };
    }
    return null;
  }

  async function waitForUnretweet(article, timeout = 2500) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      if (article.querySelector('button[data-testid="unretweet"]')) return true;
      await sleep(150);
    }
    return false;
  }

  // คืน { ok, reason } เพื่อให้บอกสาเหตุได้เวลาพลาด
  async function doRepost(article) {
    const btn = article.querySelector('button[data-testid="retweet"]');
    if (!btn) {
      // มีปุ่ม unretweet = รีโพสต์ไปแล้ว
      if (article.querySelector('button[data-testid="unretweet"]')) {
        return { ok: false, reason: "รีโพสต์ไปแล้ว" };
      }
      return { ok: false, reason: "ไม่พบปุ่มรีโพสต์ในโพสต์นี้" };
    }
    btn.scrollIntoView({ block: "center", behavior: "smooth" });
    await sleep(rand(250, 500));
    btn.click();

    // รอเมนูยืนยัน — ลอง testid ก่อน แล้ว fallback หา menuitem ที่เป็น "Repost/รีโพสต์"
    let confirm = await waitForSelector('[data-testid="retweetConfirm"]', 3500);
    if (!confirm) {
      const menu = document.querySelector('[role="menu"]');
      if (menu) {
        menu.querySelectorAll('[role="menuitem"]').forEach((it) => {
          const t = (it.textContent || "").trim();
          if (!confirm && (/repost/i.test(t) || t.includes("รีโพสต์")) && !/quote/i.test(t)) {
            confirm = it;
          }
        });
      }
    }
    if (!confirm) {
      document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
      return { ok: false, reason: "กดรีโพสต์แล้วแต่ไม่เจอเมนูยืนยัน" };
    }
    await sleep(rand(150, 400));
    confirm.click();

    // ยืนยันว่าสำเร็จจริง: ปุ่มต้องเปลี่ยนเป็น unretweet
    const ok = await waitForUnretweet(article, 2500);
    return { ok, reason: ok ? "" : "กดยืนยันแล้วแต่สถานะไม่เปลี่ยน (อาจโดน X จำกัด)" };
  }

  async function waitForUnlike(article, timeout = 2000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      if (article.querySelector('button[data-testid="unlike"]')) return true;
      await sleep(150);
    }
    return false;
  }

  // กดไลก์ (ไม่มี dialog ยืนยัน) — คืน { ok, reason }
  async function doLike(article) {
    const btn = article.querySelector('button[data-testid="like"]');
    if (!btn) {
      if (article.querySelector('button[data-testid="unlike"]')) {
        return { ok: false, reason: "ไลก์ไปแล้ว" };
      }
      return { ok: false, reason: "ไม่พบปุ่มไลก์" };
    }
    btn.scrollIntoView({ block: "center", behavior: "smooth" });
    await sleep(rand(200, 450));
    btn.click();
    const ok = await waitForUnlike(article, 2000);
    return { ok, reason: ok ? "" : "กดไลก์แล้วแต่สถานะไม่เปลี่ยน" };
  }

  // ===== โหมด UNREPOST: ยกเลิกรีโพสต์โพสต์ที่ metric ไม่ถึงเกณฑ์ =====
  function findNextReposted(processed) {
    const articles = document.querySelectorAll(
      'article[data-testid="tweet"], article[role="article"]'
    );
    for (const art of articles) {
      const r = art.getBoundingClientRect();
      if (r.width === 0 && r.height === 0) continue;
      // ต้องเป็นโพสต์ที่เรารีโพสต์ไว้แล้ว (ปุ่มอยู่สถานะ unretweet)
      if (!art.querySelector('button[data-testid="unretweet"]')) continue;
      const key = getPostKey(art);
      if (!key || processed.has(key)) continue;
      return { art, key };
    }
    return null;
  }

  // ตัดสินว่าจะยกเลิกรีโพสต์ไหม (เฉพาะ metric ที่อ่านได้และเปิดใช้งาน)
  function shouldUnrepost(m, opts) {
    const checks = [];
    if (opts.minComments > 0 && m.comments != null) checks.push(m.comments < opts.minComments);
    if (opts.minLikes > 0 && m.likes != null) checks.push(m.likes < opts.minLikes);
    if (opts.minViews > 0 && m.views != null) checks.push(m.views < opts.minViews);
    if (checks.length === 0) return false; // อ่านไม่ได้/ไม่ตั้งเกณฑ์ → ไม่ยกเลิก (ปลอดภัยไว้ก่อน)
    return opts.matchAll ? checks.every(Boolean) : checks.some(Boolean);
  }

  async function doUnrepost(article) {
    const btn = article.querySelector('button[data-testid="unretweet"]');
    if (!btn) return false;
    btn.scrollIntoView({ block: "center" });
    await sleep(rand(250, 500));
    btn.click();
    const confirm = await waitForSelector('[data-testid="unretweetConfirm"]', 3000);
    if (confirm) {
      await sleep(rand(150, 400));
      confirm.click();
      return true;
    }
    document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    return false;
  }

  // ===== โหมด DELETE: ลบโพสต์ของเราเองตามเงื่อนไข (engagement + keyword + อายุ) =====
  function getPostText(article) {
    let s = "";
    article.querySelectorAll('[data-testid="tweetText"]').forEach((e) => {
      s += " " + (e.textContent || "");
    });
    return s.toLowerCase();
  }

  function getPostAgeDays(article) {
    const t = article.querySelector("time[datetime]");
    if (!t) return null;
    const d = Date.parse(t.getAttribute("datetime"));
    if (isNaN(d)) return null;
    return (Date.now() - d) / DAY;
  }

  function postMatchesKeyword(article, keywords) {
    if (!keywords.length) return true;
    const txt = getPostText(article);
    return keywords.some((k) => txt.includes(k));
  }

  // โพสต์นี้เป็นภาษาไทยไหม — ถือว่าใช่เมื่อมีอักษรไทยและไทย ≥ อังกฤษ
  // (กันโพสต์อังกฤษล้วนที่บังเอิญมีคำไทยปนเล็กน้อย)
  function isThaiPost(article) {
    const txt = getPostText(article);
    const thai = (txt.match(/[฀-๿]/g) || []).length;
    if (thai === 0) return false;
    const latin = (txt.match(/[a-z]/gi) || []).length;
    return thai >= latin;
  }

  // คืน null = ไม่ได้ตั้งเงื่อนไขเลย, true/false = ลบ/ไม่ลบ (ต้องเข้าทุก gate ที่เปิดใช้งาน)
  function shouldDelete(article, opts) {
    const gates = [];
    const engEnabled = opts.minComments > 0 || opts.minLikes > 0 || opts.minViews > 0;
    if (engEnabled) gates.push(shouldUnrepost(getMetrics(article), opts));
    if (opts.keywords.length) gates.push(postMatchesKeyword(article, opts.keywords));
    if (opts.olderThanDays > 0) {
      const a = getPostAgeDays(article);
      gates.push(a != null && a >= opts.olderThanDays);
    }
    if (gates.length === 0) return null;
    return gates.every(Boolean);
  }

  async function doDelete(article) {
    const caret = article.querySelector('[data-testid="caret"]');
    if (!caret) return false;
    caret.scrollIntoView({ block: "center", behavior: "smooth" });
    await sleep(rand(250, 500));
    caret.click();

    const menu = await waitForSelector('[role="menu"]', 3000);
    if (!menu) return false;

    // หา menu item "Delete" / "ลบ" — ถ้าไม่เจอแปลว่าไม่ใช่โพสต์ของเรา
    let del = null;
    menu.querySelectorAll('[role="menuitem"]').forEach((it) => {
      const t = (it.textContent || "").trim();
      if (!del && (/delete/i.test(t) || t.includes("ลบ"))) del = it;
    });
    if (!del) {
      document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
      return false;
    }
    await sleep(rand(150, 350));
    del.click();

    const confirm = await waitForSelector('[data-testid="confirmationSheetConfirm"]', 3000);
    if (confirm) {
      await sleep(rand(150, 400));
      confirm.click();
      return true;
    }
    return false;
  }

  async function runDeleteLoop(settings) {
    if (running) return;
    running = true;
    stopRequested = false;

    const opts = {
      delayMin: Math.max(1, settings.delayMin) * 1000,
      delayMax: Math.max(settings.delayMin, settings.delayMax) * 1000,
      maxCount: settings.maxCount,
      hourlyLimit: settings.hourlyLimit || 0,
      dailyLimit: settings.dailyLimit || 0,
      minComments: settings.delMinComments || 0,
      minLikes: settings.delMinLikes || 0,
      minViews: settings.delMinViews || 0,
      matchAll: settings.delMatchAll !== false,
      keywords: (settings.delKeywords || []).map((k) => k.toLowerCase()),
      olderThanDays: settings.delOlderThanDays || 0,
    };

    // กันลบทั้งหมดโดยไม่ตั้งใจ: ต้องตั้งเงื่อนไขอย่างน้อย 1 ข้อ
    const anyFilter =
      opts.minComments > 0 || opts.minLikes > 0 || opts.minViews > 0 ||
      opts.keywords.length > 0 || opts.olderThanDays > 0;
    if (!anyFilter) {
      running = false;
      await setStatus("ตั้งเงื่อนไขลบอย่างน้อย 1 ข้อก่อน (กันลบทั้งหมดโดยไม่ตั้งใจ)");
      return;
    }

    let count = 0;
    let emptyScrolls = 0;
    let stopReason = "หยุดแล้ว";
    const processed = new Set();

    await writeState({ running: true, mode: "delete", count: 0, lastUser: "", statusMsg: "" });

    while (!stopRequested && (opts.maxCount === 0 || count < opts.maxCount)) {
      const lim = await checkLimit(opts.hourlyLimit, opts.dailyLimit);
      if (!lim.within) {
        stopReason = lim.reason;
        break;
      }

      let post = findNextPost(processed);
      if (!post) {
        const grew = await scrollToLoadMore();
        post = findNextPost(processed);
        if (!post) {
          emptyScrolls += grew ? 0 : 1;
          if (emptyScrolls >= 4) {
            stopReason = "ไม่พบโพสต์เพิ่มแล้ว ✓";
            break;
          }
          continue;
        }
      }
      emptyScrolls = 0;
      processed.add(post.key);

      if (shouldDelete(post.art, opts) !== true) continue;

      const ok = await doDelete(post.art);
      if (!ok) continue;

      await recordAction();
      count++;
      await writeState({ count, lastUser: "ลบโพสต์ " + post.key, statusMsg: "" });

      if ((opts.maxCount !== 0 && count >= opts.maxCount) || stopRequested) {
        stopReason = opts.maxCount !== 0 && count >= opts.maxCount ? "ครบจำนวนต่อรอบแล้ว ✓" : "หยุดแล้ว";
        break;
      }

      const wait = rand(opts.delayMin, opts.delayMax);
      const ws = Date.now();
      while (Date.now() - ws < wait) {
        if (stopRequested) break;
        await sleep(200);
      }
    }

    running = false;
    await writeState({ running: false });
    await setStatus(stopRequested ? "หยุดแล้ว" : stopReason);
  }

  async function runUnrepostLoop(settings) {
    if (running) return;
    running = true;
    stopRequested = false;

    const opts = {
      delayMin: Math.max(1, settings.delayMin) * 1000,
      delayMax: Math.max(settings.delayMin, settings.delayMax) * 1000,
      maxCount: settings.maxCount,
      hourlyLimit: settings.hourlyLimit || 0,
      dailyLimit: settings.dailyLimit || 0,
      minComments: settings.unrepMinComments || 0,
      minLikes: settings.unrepMinLikes || 0,
      minViews: settings.unrepMinViews || 0,
      matchAll: settings.unrepMatchAll !== false, // default AND
      lang: settings.unrepLang || "all", // all | removeNonThai (เก็บไทย) | removeThai
    };

    let count = 0;
    let emptyScrolls = 0;
    let stopReason = "หยุดแล้ว";
    const processed = new Set();

    await writeState({ running: true, mode: "unrepost", count: 0, lastUser: "", statusMsg: "" });

    while (!stopRequested && (opts.maxCount === 0 || count < opts.maxCount)) {
      const lim = await checkLimit(opts.hourlyLimit, opts.dailyLimit);
      if (!lim.within) {
        stopReason = lim.reason;
        break;
      }

      let post = findNextReposted(processed);
      if (!post) {
        const grew = await scrollToLoadMore();
        post = findNextReposted(processed);
        if (!post) {
          emptyScrolls += grew ? 0 : 1;
          if (emptyScrolls >= 4) {
            stopReason = "ไม่พบรีโพสต์เพิ่มแล้ว ✓";
            break;
          }
          continue;
        }
      }
      emptyScrolls = 0;
      processed.add(post.key);

      // ตัวกรองภาษา: เก็บไทย (ยกเลิกที่ไม่ใช่ไทย) / ยกเลิกเฉพาะไทย / ทุกภาษา
      if (opts.lang === "removeNonThai" && isThaiPost(post.art)) continue; // เป็นไทย → เก็บไว้
      if (opts.lang === "removeThai" && !isThaiPost(post.art)) continue; // ไม่ใช่ไทย → ข้าม

      const m = getMetrics(post.art);
      const engEnabled = opts.minComments > 0 || opts.minLikes > 0 || opts.minViews > 0;
      if (engEnabled) {
        // มีเกณฑ์ engagement → ต้อง "ต่ำกว่าเกณฑ์" ตามตรรกะ AND/OR ด้วย
        if (!shouldUnrepost(m, opts)) continue;
      } else if (opts.lang === "all") {
        // ไม่ตั้งทั้ง engagement และภาษา → ไม่ยกเลิกอะไร (กันยกเลิกหมดโดยไม่ตั้งใจ)
        continue;
      }
      // (ไม่ตั้ง engagement แต่ตั้งภาษาไว้ → ยกเลิกตามภาษาอย่างเดียว)

      const ok = await doUnrepost(post.art);
      if (!ok) continue;

      await recordAction();
      count++;
      const detail = `💬${m.comments ?? "?"} ❤️${m.likes ?? "?"} 👁${m.views ?? "?"}`;
      await writeState({ count, lastUser: "ยกเลิกรีโพสต์ — " + detail, statusMsg: "" });

      if ((opts.maxCount !== 0 && count >= opts.maxCount) || stopRequested) {
        stopReason = opts.maxCount !== 0 && count >= opts.maxCount ? "ครบจำนวนต่อรอบแล้ว ✓" : "หยุดแล้ว";
        break;
      }

      const wait = rand(opts.delayMin, opts.delayMax);
      const ws = Date.now();
      while (Date.now() - ws < wait) {
        if (stopRequested) break;
        await sleep(200);
      }
    }

    running = false;
    await writeState({ running: false });
    await setStatus(stopRequested ? "หยุดแล้ว" : stopReason);
  }

  // ===== โหมด LIKE: กดไลก์อย่างเดียว ตามตัวกรอง =====
  async function runLikeLoop(settings) {
    if (running) return;
    running = true;
    stopRequested = false;

    const opts = {
      delayMin: Math.max(1, settings.delayMin) * 1000,
      delayMax: Math.max(settings.delayMin, settings.delayMax) * 1000,
      maxCount: settings.maxCount,
      hourlyLimit: settings.hourlyLimit || 0,
      dailyLimit: settings.dailyLimit || 0,
      minViews: settings.likeMinViews || 0, // 0 = ไม่กรองยอดดู (ไลก์ทุกโพสต์ที่ตรงเงื่อนไขอื่น)
      minLikes: settings.likeMinLikes || 0, // 0 = ไม่กรองยอดไลก์
      videoOnly: settings.likeVideoOnly === true,
      followingOnly: settings.likeFollowingOnly === true,
      thaiOnly: settings.likeThaiOnly === true,
      keywords: (settings.likeKeywords || []).map((k) => k.toLowerCase()),
    };

    let count = 0;
    let emptyScrolls = 0;
    let scanned = 0;
    let maxViews = 0;
    let stopReason = "หยุดแล้ว";
    const processed = new Set();

    await writeState({ running: true, mode: "like", count: 0, lastUser: "", statusMsg: "" });

    while (!stopRequested && (opts.maxCount === 0 || count < opts.maxCount)) {
      const lim = await checkLimit(opts.hourlyLimit, opts.dailyLimit);
      if (!lim.within) {
        stopReason = lim.reason;
        break;
      }

      let post = findNextPost(processed);
      if (!post) {
        const grew = await scrollToLoadMore();
        post = findNextPost(processed);
        if (!post) {
          emptyScrolls += grew ? 0 : 1;
          if (emptyScrolls >= 4) {
            stopReason = "ไม่พบโพสต์ใหม่แล้ว ✓";
            break;
          }
          continue;
        }
      }
      emptyScrolls = 0;
      processed.add(post.key);

      post.art.scrollIntoView({ block: "center", behavior: "smooth" });
      await sleep(rand(300, 600));

      const m = getMetrics(post.art);
      const views = m.views;
      const likes = m.likes;
      scanned++;
      if (views != null && views > maxViews) maxViews = views;

      const viewsOK = opts.minViews === 0 || (views != null && views >= opts.minViews);
      const likesOK = opts.minLikes === 0 || (likes != null && likes >= opts.minLikes);
      const hasVideo = articleHasVideo(post.art);
      const followedAuthor = !opts.followingOnly || authorIsFollowed(post.art);
      const keywordOK = postMatchesKeyword(post.art, opts.keywords);
      const thaiOK = !opts.thaiOnly || isThaiPost(post.art);
      const qualify =
        viewsOK && likesOK && (!opts.videoOnly || hasVideo) && followedAuthor && keywordOK && thaiOK;

      if (!qualify) {
        await setStatus(`สแกน ${scanned} โพสต์ · ยอดดูสูงสุดที่เจอ ${maxViews.toLocaleString()}`);
        continue;
      }

      const lr = await doLike(post.art);
      if (!lr.ok) continue; // ไลก์ไปแล้ว/พลาด → ข้าม

      await recordAction();
      count++;
      const handle = getAuthorHandle(post.art);
      await writeState({ count, lastUser: (handle ? "@" + handle : "") + " — ไลก์", statusMsg: "" });

      if ((opts.maxCount !== 0 && count >= opts.maxCount) || stopRequested) {
        stopReason = opts.maxCount !== 0 && count >= opts.maxCount ? "ครบจำนวนต่อรอบแล้ว ✓" : "หยุดแล้ว";
        break;
      }

      const wait = rand(opts.delayMin, opts.delayMax);
      const ws = Date.now();
      while (Date.now() - ws < wait) {
        if (stopRequested) break;
        await sleep(200);
      }
    }

    running = false;
    await writeState({ running: false });
    await setStatus(stopRequested ? "หยุดแล้ว" : stopReason);
  }

  async function runFeedLoop(settings) {
    if (running) return;
    running = true;
    stopRequested = false;

    const opts = {
      delayMin: Math.max(1, settings.delayMin) * 1000,
      delayMax: Math.max(settings.delayMin, settings.delayMax) * 1000,
      maxCount: settings.maxCount,
      hourlyLimit: settings.hourlyLimit || 0,
      dailyLimit: settings.dailyLimit || 0,
      repostMinViews: settings.repostMinViews || 0,
      repostMinLikes: settings.feedMinLikes || 0,
      followMinFollowers: settings.followMinFollowers || 0,
      likeToo: settings.feedLike !== false, // กดไลก์ด้วยเมื่อถึงเกณฑ์ (default เปิด)
      videoOnly: settings.feedVideoOnly === true, // รีโพสต์เฉพาะโพสต์ที่มีวิดีโอ
      followingOnly: settings.feedFollowingOnly === true, // เฉพาะคนที่เราติดตาม
      thaiOnly: settings.feedThaiOnly === true, // เฉพาะโพสต์ภาษาไทย
      keywords: (settings.feedKeywords || []).map((k) => k.toLowerCase()), // คำค้นในเนื้อหา
    };

    let count = 0; // จำนวนโพสต์ที่มีการกระทำ (รีโพสต์/ติดตาม)
    let emptyScrolls = 0;
    let scanned = 0;
    let maxViews = 0;
    let stopReason = "หยุดแล้ว";
    const processed = new Set();
    const authorsHandled = new Set();

    await writeState({ running: true, mode: "feed", count: 0, lastUser: "", statusMsg: "" });

    while (!stopRequested && (opts.maxCount === 0 || count < opts.maxCount)) {
      const lim = await checkLimit(opts.hourlyLimit, opts.dailyLimit);
      if (!lim.within) {
        stopReason = lim.reason;
        break;
      }

      let post = findNextPost(processed);
      if (!post) {
        const grew = await scrollToLoadMore();
        post = findNextPost(processed);
        if (!post) {
          emptyScrolls += grew ? 0 : 1;
          if (emptyScrolls >= 4) {
            stopReason = "ไม่พบโพสต์ใหม่แล้ว ✓";
            break;
          }
          continue;
        }
      }
      emptyScrolls = 0;
      processed.add(post.key);

      // เลื่อนโพสต์ที่กำลังสแกนมากลางจอ → scrollbar เลื่อนลงตามลื่น ๆ + ปุ่มอยู่ในจอเวลาคลิก
      post.art.scrollIntoView({ block: "center", behavior: "smooth" });
      await sleep(rand(300, 600));

      const m = getMetrics(post.art);
      const views = m.views;
      const likes = m.likes;
      scanned++;
      if (views != null && views > maxViews) maxViews = views;
      // เกณฑ์ยอดดู / ไลก์ — ตั้งได้อย่างใดอย่างหนึ่งหรือทั้งคู่ (ที่ตั้งไว้ต้องผ่านทั้งหมด)
      const viewsSet = opts.repostMinViews > 0;
      const likesSet = opts.repostMinLikes > 0;
      const thresholdSet = viewsSet || likesSet;
      const viewsPass = !viewsSet || (views != null && views >= opts.repostMinViews);
      const likesPass = !likesSet || (likes != null && likes >= opts.repostMinLikes);
      const passThresholds = thresholdSet && viewsPass && likesPass;
      const hasVideo = articleHasVideo(post.art);
      const followedAuthor = !opts.followingOnly || authorIsFollowed(post.art);
      const keywordOK = postMatchesKeyword(post.art, opts.keywords);
      const thaiOK = !opts.thaiOnly || isThaiPost(post.art);
      const viewOK =
        passThresholds && (!opts.videoOnly || hasVideo) && followedAuthor && keywordOK && thaiOK;
      let acted = false;
      let label = "";

      // โชว์ความคืบหน้าระหว่างสแกน (ให้รู้ว่าทำงานอยู่ แม้ยังไม่เจอโพสต์ที่ถึงเกณฑ์)
      if (thresholdSet && !viewOK) {
        let extra = "";
        if (viewsSet && views == null) extra = " · อ่านยอดดูโพสต์นี้ไม่ได้";
        else if (likesSet && likes == null) extra = " · อ่านยอดไลก์โพสต์นี้ไม่ได้";
        else if (!viewsPass) extra = " · ยอดดูยังไม่ถึงเกณฑ์";
        else if (!likesPass) extra = " · ยอดไลก์ยังไม่ถึงเกณฑ์";
        else if (opts.videoOnly && !hasVideo) extra = " · ถึงเกณฑ์แต่ไม่ใช่วิดีโอ ข้าม";
        else if (!followedAuthor) extra = " · ถึงเกณฑ์แต่ไม่ได้ติดตามเจ้าของ ข้าม";
        else if (!keywordOK) extra = " · ถึงเกณฑ์แต่ไม่มีคำค้นในเนื้อหา ข้าม";
        else if (!thaiOK) extra = " · ถึงเกณฑ์แต่ไม่ใช่โพสต์ภาษาไทย ข้าม";
        await setStatus(
          `สแกน ${scanned} โพสต์ · ยอดดูสูงสุดที่เจอ ${maxViews.toLocaleString()}` + extra
        );
      }

      // 1) รีโพสต์ + ไลก์ ถ้าถึงเกณฑ์
      if (viewOK) {
        const metricLabel =
          views != null ? `ยอดดู ${views.toLocaleString()}` :
          likes != null ? `ไลก์ ${likes.toLocaleString()}` : "ถึงเกณฑ์";
        await setStatus(`พบโพสต์ (${metricLabel}) — กำลังรีโพสต์…`);
        const res = await doRepost(post.art);
        if (res.ok) {
          acted = true;
          label = "รีโพสต์";
          await recordAction();
        } else {
          await setStatus("รีโพสต์ไม่สำเร็จ: " + res.reason);
          await sleep(900);
        }

        // กดไลก์ด้วย (แยกจากรีโพสต์ — ทำแม้รีโพสต์ไปแล้ว)
        if (opts.likeToo) {
          const lr = await doLike(post.art);
          if (lr.ok) {
            acted = true;
            label = label ? label + " + ไลก์" : "ไลก์";
            await recordAction();
          }
        }
      }

      // 2) ติดตามเจ้าของ — พิจารณาเฉพาะโพสต์ที่ผ่านเกณฑ์ยอดดู
      //    (ถ้าปิดการรีโพสต์ไว้ จะพิจารณาทุกโพสต์)
      const considerFollow =
        opts.followMinFollowers > 0 && (!thresholdSet || viewOK);
      const handle = getAuthorHandle(post.art);
      if (considerFollow && handle && !authorsHandled.has(handle.toLowerCase())) {
        authorsHandled.add(handle.toLowerCase());
        await setStatus(`กำลังตรวจ @${handle} (ผู้ติดตาม ≥ ${opts.followMinFollowers}?)…`);
        const { followed } = await probeAuthor(handle, opts.followMinFollowers);
        if (followed) {
          acted = true;
          label = label ? label + " + ติดตาม" : "ติดตาม";
          await recordAction();
        }
      }

      if (acted) {
        count++;
        await writeState({
          count,
          lastUser: (handle ? "@" + handle : "") + (label ? " — " + label : ""),
          statusMsg: "",
        });

        if ((opts.maxCount !== 0 && count >= opts.maxCount) || stopRequested) {
          stopReason = opts.maxCount !== 0 && count >= opts.maxCount ? "ครบจำนวนต่อรอบแล้ว ✓" : "หยุดแล้ว";
          break;
        }

        const wait = rand(opts.delayMin, opts.delayMax);
        const ws = Date.now();
        while (Date.now() - ws < wait) {
          if (stopRequested) break;
          await sleep(200);
        }
      }
    }

    running = false;
    await writeState({ running: false });
    await setStatus(stopRequested ? "หยุดแล้ว" : stopReason);
  }

  // ===== โหมด LAZADA: ดึงสินค้าจาก Lazada (ผ่าน background) แล้วโพสต์ลง X =====
  // แทนค่า {name} {price} {sold} {reviews} {rating} {link} {url} {hashtags} ในเทมเพลต
  function buildTweet(tmpl, p, hashtags) {
    const map = {
      name: p.name || "",
      price: p.price || "",
      sold: p.sold != null ? String(p.sold) : "",
      reviews: p.reviews != null ? String(p.reviews) : "",
      rating: p.rating || "",
      link: p.affLink || p.url || "",
      url: p.url || "",
      hashtags: hashtags || "",
    };
    let t = (tmpl || "{name}\n{link}").replace(/\{(\w+)\}/g, (m, k) =>
      k in map ? map[k] : m
    );
    // ลบบรรทัดที่ว่างเปล่าจากตัวแปรที่ไม่มีค่า + บีบช่องว่างซ้ำ
    t = t
      .split("\n")
      .map((l) => l.replace(/\s+\|\s+/g, " | ").trim())
      .filter((l) => l.length > 0)
      .join("\n");
    if (hashtags && !/\{hashtags\}/.test(tmpl || "")) t += "\n" + hashtags;
    return t.trim();
  }

  // เปิดกล่องเขียนโพสต์ (โมดอล) โดยไม่รีโหลดหน้า → loop ไม่ขาด
  async function openComposer() {
    let box = document.querySelector('[data-testid="tweetTextarea_0"]');
    if (box) return box;
    const newBtn =
      document.querySelector('a[data-testid="SideNav_NewTweet_Button"]') ||
      document.querySelector('[data-testid="SideNav_NewTweet_Button"]') ||
      document.querySelector('a[href="/compose/post"]');
    if (newBtn) {
      newBtn.click();
    } else {
      // fallback: คีย์ลัด "n" ของ X เพื่อเปิดกล่องเขียนโพสต์
      document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "n", bubbles: true }));
    }
    return await waitForSelector('[data-testid="tweetTextarea_0"]', 6000);
  }

  async function typeIntoComposer(box, text) {
    box.focus();
    await sleep(150);
    // ล้างของเดิม (เผื่อมี draft ค้าง) แล้วพิมพ์ใหม่ผ่าน execCommand (Draft.js รองรับ)
    document.execCommand("selectAll", false, null);
    document.execCommand("delete", false, null);
    document.execCommand("insertText", false, text);
    box.dispatchEvent(new InputEvent("input", { bubbles: true }));
    await sleep(rand(400, 800));
  }

  async function clickPostButton() {
    let btn =
      document.querySelector('[data-testid="tweetButton"]') ||
      document.querySelector('[data-testid="tweetButtonInline"]');
    if (!btn) return false;
    const start = Date.now();
    while (Date.now() - start < 4000) {
      const disabled =
        btn.getAttribute("aria-disabled") === "true" || btn.disabled === true;
      if (!disabled) break;
      await sleep(150);
    }
    btn.scrollIntoView({ block: "center" });
    await sleep(rand(200, 400));
    btn.click();
    return true;
  }

  // โพสต์ 1 ทวีต — คืน true เมื่อกล่องเขียนปิดลง (ถือว่าโพสต์สำเร็จ)
  async function postTweet(text) {
    // ปิดโมดอลค้างก่อน (ถ้ามี)
    document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    await sleep(300);

    const box = await openComposer();
    if (!box) return false;
    await typeIntoComposer(box, text);
    const clicked = await clickPostButton();
    if (!clicked) {
      document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
      return false;
    }
    // ยืนยันสำเร็จ: กล่องเขียนหายไป
    const start = Date.now();
    while (Date.now() - start < 8000) {
      if (!document.querySelector('[data-testid="tweetTextarea_0"]')) return true;
      await sleep(200);
    }
    // ยังไม่ปิด → อาจติด rate limit/ผิดพลาด
    document.body.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    return false;
  }

  async function runLazadaLoop(settings) {
    if (running) return;
    running = true;
    stopRequested = false;

    const opts = {
      delayMin: Math.max(1, settings.delayMin) * 1000,
      delayMax: Math.max(settings.delayMin, settings.delayMax) * 1000,
      maxCount: settings.maxCount,
      hourlyLimit: settings.hourlyLimit || 0,
      dailyLimit: settings.dailyLimit || 0,
    };

    await writeState({ running: true, mode: "lazada", count: 0, lastUser: "", statusMsg: "" });
    await setStatus("กำลังดึงสินค้าจาก Lazada…");

    let resp;
    try {
      resp = await chrome.runtime.sendMessage({
        type: "LAZADA_FETCH",
        cfg: {
          keywords: settings.lzKeywords || [],
          minSold: settings.lzMinSold || 0,
          minReviews: settings.lzMinReviews || 0,
          perKeyword: settings.lzPerKeyword || 20,
          maxProducts: opts.maxCount || 50,
          sortBy: settings.lzSortBy || "sold",
          manualList: settings.lzManualList || "",
          apiBase: settings.lzApiBase || "",
          appKey: settings.lzAppKey || "",
          appSecret: settings.lzAppSecret || "",
          accessToken: settings.lzAccessToken || "",
          searchPath: settings.lzSearchPath || "",
          linkMode: settings.lzLinkMode || "template",
          linkTemplate: settings.lzLinkTemplate || "{rawurl}",
          linkPath: settings.lzLinkPath || "",
          subId: settings.lzSubId || "",
        },
      });
    } catch (e) {
      resp = { ok: false, error: "ติดต่อ background ไม่ได้" };
    }

    if (!resp || !resp.ok) {
      running = false;
      await writeState({ running: false });
      await setStatus("ดึงสินค้าไม่สำเร็จ: " + ((resp && resp.error) || "ไม่ทราบสาเหตุ"));
      return;
    }
    const products = resp.products || [];
    if (!products.length) {
      running = false;
      await writeState({ running: false });
      await setStatus("ไม่พบสินค้าที่ผ่านเงื่อนไข — ลองลดยอดขาย/รีวิวขั้นต่ำ หรือใส่ Manual list");
      return;
    }

    let count = 0;
    let stopReason = "หยุดแล้ว";

    for (const p of products) {
      if (stopRequested) {
        stopReason = "หยุดแล้ว";
        break;
      }
      if (opts.maxCount !== 0 && count >= opts.maxCount) {
        stopReason = "ครบจำนวนต่อรอบแล้ว ✓";
        break;
      }
      const lim = await checkLimit(opts.hourlyLimit, opts.dailyLimit);
      if (!lim.within) {
        stopReason = lim.reason;
        break;
      }

      const text = buildTweet(settings.lzTemplate, p, settings.lzHashtags || "");
      const label = (p.name || "สินค้า").slice(0, 40);
      await setStatus(`กำลังโพสต์: ${label}…`);

      const ok = await postTweet(text);
      if (!ok) {
        await setStatus(`โพสต์ "${label}" ไม่สำเร็จ — ข้าม (อาจโดน X จำกัด/ไม่เจอกล่องเขียน)`);
        await sleep(1500);
        continue;
      }

      await recordAction();
      count++;
      await writeState({ count, lastUser: (p.name || "สินค้า").slice(0, 50), statusMsg: "" });

      if ((opts.maxCount !== 0 && count >= opts.maxCount) || stopRequested) {
        stopReason =
          opts.maxCount !== 0 && count >= opts.maxCount ? "ครบจำนวนต่อรอบแล้ว ✓" : "หยุดแล้ว";
        break;
      }

      const wait = rand(opts.delayMin, opts.delayMax);
      const ws = Date.now();
      while (Date.now() - ws < wait) {
        if (stopRequested) break;
        await sleep(200);
      }
    }

    if (!stopRequested && count >= products.length) stopReason = "โพสต์ครบทุกสินค้าแล้ว ✓";
    running = false;
    await writeState({ running: false });
    await setStatus(stopRequested ? "หยุดแล้ว" : stopReason);
  }

  async function runLoop(settings) {
    if (settings.mode === "lazada") return runLazadaLoop(settings);
    if (settings.mode === "feed") return runFeedLoop(settings);
    if (settings.mode === "like") return runLikeLoop(settings);
    if (settings.mode === "unrepost") return runUnrepostLoop(settings);
    if (settings.mode === "delete") return runDeleteLoop(settings);
    if (running) return;
    running = true;
    stopRequested = false;

    const mode = settings.mode === "follow" ? "follow" : "unfollow";
    const opts = {
      delayMin: Math.max(1, settings.delayMin) * 1000,
      delayMax: Math.max(settings.delayMin, settings.delayMax) * 1000,
      maxCount: settings.maxCount,
      hourlyLimit: settings.hourlyLimit || 0,
      dailyLimit: settings.dailyLimit || 0,
      // unfollow
      nonMutualOnly: !!settings.nonMutualOnly,
      whitelist: (settings.whitelist || []).map((h) => h.toLowerCase()),
      // follow
      verifiedOnly: !!settings.verifiedOnly,
      minFollowers: settings.minFollowers || 0,
      bioKeywords: (settings.bioKeywords || []).map((k) => k.toLowerCase()),
    };

    let count = 0;
    let emptyScrolls = 0;
    let stopReason = "หยุดแล้ว";
    const skipped = new Set();

    await writeState({ running: true, mode, count: 0, lastUser: "", statusMsg: "" });

    while (!stopRequested && (opts.maxCount === 0 || count < opts.maxCount)) {
      const lim = await checkLimit(opts.hourlyLimit, opts.dailyLimit);
      if (!lim.within) {
        stopReason = lim.reason;
        break;
      }

      let item = mode === "follow" ? findNextFollow(opts, skipped) : findNextUnfollow(opts, skipped);

      if (!item) {
        const grew = await scrollToLoadMore();
        item = mode === "follow" ? findNextFollow(opts, skipped) : findNextUnfollow(opts, skipped);
        if (!item) {
          emptyScrolls += grew ? 0 : 1;
          if (emptyScrolls >= 3) {
            stopReason = "หมดรายชื่อแล้ว ✓";
            break;
          }
          continue;
        }
      }
      emptyScrolls = 0;

      // โหมด follow + ต้องเช็คจำนวนผู้ติดตาม → เปิดโปรไฟล์ทีละคน
      if (mode === "follow" && opts.minFollowers > 0 && item.handle) {
        await setStatus(`กำลังตรวจผู้ติดตามของ @${item.handle}…`);
        const { followers } = await probeAuthor(item.handle, null);
        if (followers == null || followers < opts.minFollowers) {
          skipped.add(item.handle.toLowerCase());
          continue; // ไม่ผ่านเกณฑ์ → ข้าม
        }
      }

      if (mode === "follow") {
        await clickFollowButton(item.btn);
      } else {
        await clickUnfollowButton(item.btn);
      }
      if (item.handle) skipped.add(item.handle.toLowerCase());

      await recordAction();
      count++;
      await writeState({ count, lastUser: item.display, statusMsg: "" });

      if ((opts.maxCount !== 0 && count >= opts.maxCount) || stopRequested) {
        stopReason = opts.maxCount !== 0 && count >= opts.maxCount ? "ครบจำนวนต่อรอบแล้ว ✓" : "หยุดแล้ว";
        break;
      }

      // เลื่อนหน้าลงเล็กน้อยให้เห็นความคืบหน้า + โหลดรายชื่อถัดไปลื่นขึ้น
      window.scrollBy({ top: rand(250, 450), behavior: "smooth" });
      await sleep(400);

      const wait = rand(opts.delayMin, opts.delayMax);
      const waitStart = Date.now();
      while (Date.now() - waitStart < wait) {
        if (stopRequested) break;
        await sleep(200);
      }
    }

    running = false;
    await writeState({ running: false });
    await setStatus(stopRequested ? "หยุดแล้ว" : stopReason);
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "PING") {
      sendResponse({ ok: true, onFollowing: isOnFollowingPage() });
      return true;
    }
    if (msg.type === "START") {
      const mode = (msg.settings && msg.settings.mode) || "unfollow";
      if (mode === "unfollow" && !isOnFollowingPage()) {
        sendResponse({ ok: false, reason: "not-following-page" });
        return true;
      }
      runLoop(msg.settings);
      sendResponse({ ok: true });
      return true;
    }
    if (msg.type === "STOP") {
      stopRequested = true;
      sendResponse({ ok: true });
      return true;
    }
  });
})();
