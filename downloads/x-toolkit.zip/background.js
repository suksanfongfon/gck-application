// background.js — service worker
// 1) ตั้งค่าเริ่มต้นเมื่อติดตั้ง
// 2) เปิดโปรไฟล์ใน background tab เพื่ออ่านจำนวนผู้ติดตาม (probe) ให้โหมด Follow
// 3) เป็นศูนย์กลาง: บอก tabId, คุมลิมิตรวม (history) แบบ serialize กัน race ข้ามแท็บ

const HOUR = 3600 * 1000;
const DAY = 24 * HOUR;

const pendingProbes = new Map(); // tabId -> { resolve, timer }

// ============================================================
// ===== Lazada: ค้นหาสินค้า + กรอง + สร้าง affiliate link =====
// ============================================================
// อ้างอิงวิธี sign ของ Lazada Open Platform (LazOP /rest):
//   1) รวม system + business params (ไม่รวม sign)
//   2) เรียงคีย์ตาม ASCII
//   3) ต่อสตริง = apiPath + (key+value ต่อกันไปเรื่อย ๆ ไม่มีตัวคั่น)
//   4) HMAC-SHA256(key = appSecret) แล้วแปลงเป็น hex ตัวพิมพ์ใหญ่

async function hmacSha256Hex(secret, msg) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw",
    enc.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(msg));
  return [...new Uint8Array(sig)]
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("")
    .toUpperCase();
}

function lazSignBase(apiPath, params) {
  const keys = Object.keys(params).sort();
  let s = apiPath;
  for (const k of keys) s += k + params[k];
  return s;
}

// เรียก Lazada Open Platform API (GET) พร้อม sign — คืน JSON
async function lazApiCall(apiBase, apiPath, appKey, appSecret, accessToken, business) {
  if (!apiBase || !apiPath || !appKey || !appSecret) {
    throw new Error("ต้องตั้ง API base / app key / app secret ก่อน");
  }
  const params = {
    app_key: appKey,
    timestamp: String(Date.now()),
    sign_method: "sha256",
    ...(accessToken ? { access_token: accessToken } : {}),
    ...business,
  };
  // ค่าที่ใช้ sign ต้องเป็น string ทั้งหมด
  for (const k of Object.keys(params)) params[k] = String(params[k]);
  params.sign = await hmacSha256Hex(appSecret, lazSignBase(apiPath, params));

  const qs = new URLSearchParams(params).toString();
  const url = apiBase.replace(/\/+$/, "") + apiPath + "?" + qs;
  const res = await fetch(url, { method: "GET" });
  const text = await res.text();
  let json;
  try {
    json = JSON.parse(text);
  } catch (e) {
    throw new Error("ตอบกลับไม่ใช่ JSON: " + text.slice(0, 200));
  }
  if (json && json.code && json.code !== "0" && json.code !== 0) {
    throw new Error("Lazada API: " + (json.message || json.code));
  }
  return json;
}

// หา array ของรายการสินค้าใน JSON (รองรับหลายรูปแบบ response)
function findItemArray(obj, depth = 0) {
  if (!obj || depth > 6) return null;
  if (Array.isArray(obj)) {
    const looksLikeItems = obj.some(
      (x) => x && typeof x === "object" && !Array.isArray(x)
    );
    return looksLikeItems ? obj : null;
  }
  if (typeof obj !== "object") return null;
  // คีย์ที่มักเก็บรายการสินค้า
  const prefer = ["items", "products", "data", "result", "list", "records"];
  for (const k of prefer) {
    if (obj[k]) {
      const found = findItemArray(obj[k], depth + 1);
      if (found && found.length) return found;
    }
  }
  for (const k of Object.keys(obj)) {
    const found = findItemArray(obj[k], depth + 1);
    if (found && found.length) return found;
  }
  return null;
}

// ดึงค่าจาก object ตามชื่อคีย์ที่เป็นไปได้หลายแบบ (case-insensitive)
function pickField(item, names) {
  const lowerMap = {};
  for (const k of Object.keys(item)) lowerMap[k.toLowerCase()] = item[k];
  for (const n of names) {
    const v = lowerMap[n.toLowerCase()];
    if (v != null && v !== "") return v;
  }
  return null;
}

function toNum(v) {
  if (v == null) return null;
  const m = String(v).replace(/,/g, "").match(/[\d.]+/);
  return m ? Math.round(parseFloat(m[0])) : null;
}

// map รายการดิบ → โครงสร้างสินค้าที่เราใช้
function mapProduct(item) {
  const name = pickField(item, [
    "name", "title", "itemName", "productName", "subject",
  ]);
  const url = pickField(item, [
    "productUrl", "itemUrl", "url", "promotionLink", "link", "detailUrl",
  ]);
  const price = pickField(item, [
    "priceShow", "price", "salePrice", "discountPrice", "minPrice",
  ]);
  const image = pickField(item, [
    "image", "imageUrl", "mainImage", "picUrl", "img",
  ]);
  const sold = toNum(
    pickField(item, ["sold", "soldCount", "sales", "salesVolume", "tradeCount", "orders"])
  );
  const reviews = toNum(
    pickField(item, ["reviews", "ratingCount", "reviewCount", "comments", "commentCount"])
  );
  const rating = pickField(item, ["rating", "ratingScore", "averageStar", "score"]);
  return {
    name: name ? String(name) : "",
    url: url ? String(url) : "",
    price: price != null ? String(price) : "",
    image: image ? String(image) : "",
    sold,
    reviews,
    rating: rating != null ? String(rating) : "",
    affLink: "",
    _raw: item,
  };
}

// แปลง manual list (บรรทัดละสินค้า: name | price | sold | reviews | url) → products
function parseManualList(text) {
  const out = [];
  for (const line of (text || "").split("\n")) {
    const t = line.trim();
    if (!t) continue;
    const parts = t.split("|").map((s) => s.trim());
    // ถ้ามีแค่ URL เดียวก็รับได้
    if (parts.length === 1 && /^https?:\/\//i.test(parts[0])) {
      out.push({ name: "", price: "", sold: null, reviews: null, url: parts[0], image: "", rating: "", affLink: "" });
      continue;
    }
    const [name, price, sold, reviews, url] = parts;
    out.push({
      name: name || "",
      price: price || "",
      sold: toNum(sold),
      reviews: toNum(reviews),
      url: url || "",
      image: "",
      rating: "",
      affLink: "",
    });
  }
  return out;
}

// สร้าง affiliate link — โหมด template (ต่อพารามิเตอร์เอง) หรือ api (เรียก Lazada)
async function buildAffLink(product, cfg) {
  const productUrl = product.url || "";
  if (!productUrl) return "";
  if (cfg.linkMode === "api" && cfg.linkPath) {
    try {
      const json = await lazApiCall(
        cfg.apiBase, cfg.linkPath, cfg.appKey, cfg.appSecret, cfg.accessToken,
        { url: productUrl, ...(cfg.subId ? { sub_id: cfg.subId } : {}) }
      );
      // หา string ที่หน้าตาเป็นลิงก์ในผลลัพธ์
      const flat = JSON.stringify(json);
      const m = flat.match(/"(https?:\\?\/\\?\/[^"]+)"/);
      if (m) return m[1].replace(/\\\//g, "/");
    } catch (e) {
      // ถ้า API พลาด → fallback เป็น template
    }
  }
  // template: แทน {url} (encode) / {rawurl} (ไม่ encode) / {sub}
  const tmpl = cfg.linkTemplate || "{url}";
  return tmpl
    .replace(/\{url\}/g, encodeURIComponent(productUrl))
    .replace(/\{rawurl\}/g, productUrl)
    .replace(/\{sub\}/g, cfg.subId || "");
}

async function lazadaFetch(cfg) {
  let products = [];

  // 1) มาจาก manual list ก่อน (ถ้ามี)
  if (cfg.manualList && cfg.manualList.trim()) {
    products = parseManualList(cfg.manualList);
  } else if (cfg.searchPath && cfg.appKey) {
    // 2) ค้นหาผ่าน API ตามคีย์เวิร์ด
    const keywords = (cfg.keywords || []).filter(Boolean);
    if (!keywords.length) throw new Error("ใส่คำค้นหาสินค้าอย่างน้อย 1 บรรทัด");
    const seen = new Set();
    for (const kw of keywords) {
      const json = await lazApiCall(
        cfg.apiBase, cfg.searchPath, cfg.appKey, cfg.appSecret, cfg.accessToken,
        { keyword: kw, q: kw, page_size: String(cfg.perKeyword || 20), limit: String(cfg.perKeyword || 20) }
      );
      const arr = findItemArray(json) || [];
      for (const it of arr) {
        const p = mapProduct(it);
        const key = p.url || p.name;
        if (!key || seen.has(key)) continue;
        seen.add(key);
        products.push(p);
      }
    }
  } else {
    throw new Error("ยังไม่ได้ตั้งค่า: ใส่ Manual list หรือกรอก API (app key + search path)");
  }

  // 3) กรองตามยอดขาย / รีวิวขั้นต่ำ (ค่าที่อ่านไม่ได้ = ไม่ผ่านเฉพาะเมื่อมีเกณฑ์)
  const minSold = cfg.minSold || 0;
  const minReviews = cfg.minReviews || 0;
  if (minSold > 0) products = products.filter((p) => p.sold != null && p.sold >= minSold);
  if (minReviews > 0) products = products.filter((p) => p.reviews != null && p.reviews >= minReviews);

  // 4) เรียงลำดับ (ยอดขาย / รีวิว มาก→น้อย) แล้วตัดตามจำนวนสูงสุด
  const sortKey = cfg.sortBy === "reviews" ? "reviews" : "sold";
  products.sort((a, b) => (b[sortKey] || 0) - (a[sortKey] || 0));
  if (cfg.maxProducts > 0) products = products.slice(0, cfg.maxProducts);

  // 5) สร้าง affiliate link ให้ทุกตัว
  for (const p of products) {
    p.affLink = await buildAffLink(p, cfg);
    delete p._raw;
  }
  return products;
}

// ===== ประวัติการกระทำรวม (ใช้ร่วมทุกแท็บ) — เข้าถึงแบบต่อคิวกัน race =====
let histCache = null;
let histChain = Promise.resolve();

async function ensureHist() {
  if (histCache === null) {
    histCache = (await chrome.storage.local.get("history")).history || [];
  }
}

// op(history) ทำงานบน array แล้วคืนค่าผลลัพธ์; เราจะ prune + persist ให้อัตโนมัติ
function histOp(op) {
  const next = histChain.then(async () => {
    await ensureHist();
    histCache = histCache.filter((t) => Date.now() - t < DAY);
    const result = op(histCache);
    await chrome.storage.local.set({ history: histCache });
    return result;
  });
  histChain = next.catch(() => {});
  return next;
}

function probeFollowers(handle, followThreshold) {
  // followThreshold เป็นตัวเลข → ให้แท็บ probe กดติดตามด้วยถ้าถึงเกณฑ์
  const hash =
    typeof followThreshold === "number" && followThreshold > 0
      ? `#xuf_probe_follow_${followThreshold}`
      : "#xuf_probe";
  const url = `https://x.com/${encodeURIComponent(handle)}${hash}`;
  return new Promise((resolve) => {
    chrome.tabs
      .create({ url, active: false })
      .then((tab) => {
        const timer = setTimeout(() => {
          pendingProbes.delete(tab.id);
          chrome.tabs.remove(tab.id).catch(() => {});
          resolve({ followers: null, followed: false }); // timeout
        }, 15000);
        pendingProbes.set(tab.id, { resolve, timer });
      })
      .catch(() => resolve({ followers: null, followed: false }));
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "GET_TAB_ID") {
    sendResponse({ tabId: sender.tab ? sender.tab.id : null });
    return false;
  }

  if (msg.type === "CHECK_LIMIT") {
    histOp((h) => {
      const now = Date.now();
      const lastHour = h.filter((t) => now - t < HOUR).length;
      const lastDay = h.length; // prune เป็น 24 ชม. แล้ว
      return { lastHour, lastDay };
    }).then(({ lastHour, lastDay }) => {
      let within = true;
      let reason = "";
      if (msg.hourlyLimit && lastHour >= msg.hourlyLimit) {
        within = false;
        reason = `ถึงลิมิตต่อชั่วโมง (${msg.hourlyLimit}) — ลองใหม่ภายหลัง`;
      } else if (msg.dailyLimit && lastDay >= msg.dailyLimit) {
        within = false;
        reason = `ถึงลิมิตต่อวัน (${msg.dailyLimit}) — ลองใหม่พรุ่งนี้`;
      }
      sendResponse({ within, reason, lastHour, lastDay });
    });
    return true; // async
  }

  if (msg.type === "RECORD_ACTION") {
    histOp((h) => {
      h.push(Date.now());
    }).then(() => sendResponse({ ok: true }));
    return true; // async
  }

  if (msg.type === "PROBE_FOLLOWERS") {
    probeFollowers(msg.handle, msg.followThreshold).then((res) => sendResponse(res));
    return true; // ตอบแบบ async
  }

  if (msg.type === "LAZADA_FETCH") {
    lazadaFetch(msg.cfg || {})
      .then((products) => sendResponse({ ok: true, products }))
      .catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true; // async
  }
  if (msg.type === "PROBE_RESULT") {
    const tabId = sender.tab && sender.tab.id;
    const p = pendingProbes.get(tabId);
    if (p) {
      clearTimeout(p.timer);
      pendingProbes.delete(tabId);
      p.resolve({ followers: msg.followers, followed: !!msg.followed });
    }
    if (tabId) chrome.tabs.remove(tabId).catch(() => {});
    return false;
  }
});

// ลบสถานะของแท็บที่ถูกปิด (xufState_<tabId>)
chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.local.remove("xufState_" + tabId).catch(() => {});
  const p = pendingProbes.get(tabId);
  if (p) {
    clearTimeout(p.timer);
    pendingProbes.delete(tabId);
    p.resolve({ followers: null, followed: false });
  }
});

// ตั้งค่าเริ่มต้นเมื่อติดตั้งครั้งแรก

chrome.runtime.onInstalled.addListener(async () => {
  const existing = await chrome.storage.local.get([
    "delayMin",
    "delayMax",
    "maxCount",
    "noLimit",
    "nonMutualOnly",
    "hourlyLimit",
    "dailyLimit",
    "whitelist",
    "history",
    "mode",
    "verifiedOnly",
    "minFollowers",
    "bioKeywords",
    "repostMinViews",
    "feedMinLikes",
    "followMinFollowers",
    "feedLike",
    "feedVideoOnly",
    "feedFollowingOnly",
    "feedThaiOnly",
    "feedKeywords",
    "likeMinViews",
    "likeMinLikes",
    "likeVideoOnly",
    "likeFollowingOnly",
    "likeThaiOnly",
    "likeKeywords",
    "unrepMinComments",
    "unrepMinLikes",
    "unrepMinViews",
    "unrepMatchAll",
    "unrepLang",
    "delMinComments",
    "delMinLikes",
    "delMinViews",
    "delMatchAll",
    "delKeywords",
    "delOlderThanDays",
    "lzKeywords",
    "lzMinSold",
    "lzMinReviews",
    "lzPerKeyword",
    "lzSortBy",
    "lzTemplate",
    "lzHashtags",
    "lzManualList",
    "lzApiBase",
    "lzAppKey",
    "lzAppSecret",
    "lzAccessToken",
    "lzSearchPath",
    "lzLinkMode",
    "lzLinkTemplate",
    "lzLinkPath",
    "lzSubId",
  ]);
  const defaults = {};
  if (existing.delayMin == null) defaults.delayMin = 4;
  if (existing.delayMax == null) defaults.delayMax = 9;
  if (existing.maxCount == null) defaults.maxCount = 50;
  if (existing.noLimit == null) defaults.noLimit = false;
  if (existing.nonMutualOnly == null) defaults.nonMutualOnly = false;
  if (existing.hourlyLimit == null) defaults.hourlyLimit = 0;
  if (existing.dailyLimit == null) defaults.dailyLimit = 0;
  if (existing.whitelist == null) defaults.whitelist = [];
  if (existing.history == null) defaults.history = [];
  if (existing.mode == null) defaults.mode = "unfollow";
  if (existing.verifiedOnly == null) defaults.verifiedOnly = false;
  if (existing.minFollowers == null) defaults.minFollowers = 0;
  if (existing.bioKeywords == null) defaults.bioKeywords = [];
  if (existing.repostMinViews == null) defaults.repostMinViews = 100000;
  if (existing.feedMinLikes == null) defaults.feedMinLikes = 0;
  if (existing.followMinFollowers == null) defaults.followMinFollowers = 100000;
  if (existing.feedLike == null) defaults.feedLike = true;
  if (existing.feedVideoOnly == null) defaults.feedVideoOnly = false;
  if (existing.feedFollowingOnly == null) defaults.feedFollowingOnly = false;
  if (existing.feedThaiOnly == null) defaults.feedThaiOnly = false;
  if (existing.feedKeywords == null) defaults.feedKeywords = [];
  if (existing.likeMinViews == null) defaults.likeMinViews = 0;
  if (existing.likeMinLikes == null) defaults.likeMinLikes = 0;
  if (existing.likeVideoOnly == null) defaults.likeVideoOnly = false;
  if (existing.likeFollowingOnly == null) defaults.likeFollowingOnly = false;
  if (existing.likeThaiOnly == null) defaults.likeThaiOnly = false;
  if (existing.likeKeywords == null) defaults.likeKeywords = [];
  if (existing.unrepMinComments == null) defaults.unrepMinComments = 0;
  if (existing.unrepMinLikes == null) defaults.unrepMinLikes = 0;
  if (existing.unrepMinViews == null) defaults.unrepMinViews = 0;
  if (existing.unrepMatchAll == null) defaults.unrepMatchAll = true;
  if (existing.unrepLang == null) defaults.unrepLang = "all";
  if (existing.delMinComments == null) defaults.delMinComments = 0;
  if (existing.delMinLikes == null) defaults.delMinLikes = 0;
  if (existing.delMinViews == null) defaults.delMinViews = 0;
  if (existing.delMatchAll == null) defaults.delMatchAll = true;
  if (existing.delKeywords == null) defaults.delKeywords = [];
  if (existing.delOlderThanDays == null) defaults.delOlderThanDays = 0;
  if (existing.lzKeywords == null) defaults.lzKeywords = [];
  if (existing.lzMinSold == null) defaults.lzMinSold = 100;
  if (existing.lzMinReviews == null) defaults.lzMinReviews = 0;
  if (existing.lzPerKeyword == null) defaults.lzPerKeyword = 20;
  if (existing.lzSortBy == null) defaults.lzSortBy = "sold";
  if (existing.lzTemplate == null)
    defaults.lzTemplate =
      "{name}\n💰 {price} | ⭐ {rating} ({reviews} รีวิว) | 🛒 ขายแล้ว {sold}\n👉 {link}";
  if (existing.lzHashtags == null) defaults.lzHashtags = "";
  if (existing.lzManualList == null) defaults.lzManualList = "";
  if (existing.lzApiBase == null) defaults.lzApiBase = "https://api.lazada.co.th/rest";
  if (existing.lzAppKey == null) defaults.lzAppKey = "";
  if (existing.lzAppSecret == null) defaults.lzAppSecret = "";
  if (existing.lzAccessToken == null) defaults.lzAccessToken = "";
  if (existing.lzSearchPath == null) defaults.lzSearchPath = "";
  if (existing.lzLinkMode == null) defaults.lzLinkMode = "template";
  if (existing.lzLinkTemplate == null) defaults.lzLinkTemplate = "{rawurl}";
  if (existing.lzLinkPath == null) defaults.lzLinkPath = "";
  if (existing.lzSubId == null) defaults.lzSubId = "";
  defaults.running = false;
  defaults.count = 0;
  defaults.lastUser = "";
  defaults.statusMsg = "";
  await chrome.storage.local.set(defaults);
});
