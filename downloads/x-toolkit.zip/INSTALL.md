# การติดตั้ง X Toolkit

มี 2 ทาง — แนะนำ **แบบ unpacked** สำหรับใช้เอง (ฟรี ไม่ต้องรอรีวิว)

---

## วิธีที่ 1 — Load unpacked (ใช้เอง / ดีสุดสำหรับเครื่องมือ automation)

1. เปิด Chrome ไปที่ `chrome://extensions`
2. เปิด **Developer mode** (สวิตช์มุมขวาบน)
3. กด **Load unpacked**
4. เลือกโฟลเดอร์โปรเจกต์นี้ (`chrom extendion 2`)
5. ปักหมุดไอคอน **X Toolkit** ไว้ที่ทูลบาร์

### อัปเดตเวอร์ชัน (หลังแก้โค้ด)
- ไปที่ `chrome://extensions` → กดปุ่ม **reload (⟳)** ที่การ์ด X Toolkit
- ถ้าแก้ `content.js` ให้ **refresh หน้า x.com** ที่เปิดอยู่ด้วย

> ข้อดี: ไม่ต้องจ่าย ไม่ต้องรีวิว แก้แล้วใช้ได้ทันที
> ข้อจำกัด: ใช้ได้เฉพาะเครื่องที่โหลดโฟลเดอร์นี้ไว้ (Chrome จะเตือน "developer mode" เป็นระยะ — ปกติ)

---

## วิธีที่ 2 — Chrome Web Store (แจกให้คนอื่น)

ดูขั้นตอนเต็มในไฟล์ [store/STORE-LISTING.md](store/STORE-LISTING.md) และ
[store/PRIVACY-POLICY.md](store/PRIVACY-POLICY.md)

สรุปสั้น:
1. สมัคร Developer Console → https://chrome.google.com/webstore/devconsole (จ่าย $5 ครั้งเดียว)
2. **New item** → อัปโหลด `x-toolkit.zip` (อยู่ในโฟลเดอร์นี้)
3. กรอก Store listing + Privacy practices (ก็อปจาก STORE-LISTING.md)
4. ใส่ Privacy Policy URL (โฮสต์ PRIVACY-POLICY.md เป็นหน้าเว็บก่อน)
5. อัป screenshot อย่างน้อย 1 รูป (1280×800)
6. **Submit for review**

### เลือกระดับการเผยแพร่
- **Unlisted** — เข้าได้เฉพาะคนที่มีลิงก์ (แนะนำสำหรับเครื่องมือแบบนี้)
- **Public** — โผล่ในการค้นหา ⚠️ เสี่ยงโดนปฏิเสธจากนโยบาย automation/spam

> ⚠️ เครื่องมือที่ทำงานอัตโนมัติบน X / โพสต์ affiliate มีโอกาสถูกปฏิเสธหรือถอดสูง
> ถ้าจะใช้ส่วนตัว วิธีที่ 1 (unpacked) เหมาะกว่ามาก

---

## สร้างไฟล์ zip ใหม่ (เมื่อแก้โค้ดแล้วจะอัปใหม่)

รันในโฟลเดอร์โปรเจกต์:
```bash
rm -f x-toolkit.zip
zip -r x-toolkit.zip manifest.json background.js content.js popup.html popup.css popup.js icons -x "*.DS_Store"
```
อย่าลืม **เพิ่มเลข version** ใน `manifest.json` ทุกครั้งที่อัปเวอร์ชันใหม่ขึ้น Store
