# Privacy Policy — X Toolkit

_Last updated: 2026-06-02_

X Toolkit ("the extension") is a browser tool that automates actions on your own
X (Twitter) account and, optionally, helps you post Lazada products with your own
affiliate links. This policy explains exactly what data the extension touches.

## TL;DR

- We do **not** collect, transmit, sell, or share any personal data.
- Everything you enter stays **on your own device** (Chrome local storage).
- The extension talks only to **x.com / twitter.com** (your own logged-in session)
  and, only in Lazada mode, to the **Lazada API** using credentials you provide.
- There are **no analytics, no trackers, and no developer servers**.

## What data the extension stores (locally only)

All data is saved with `chrome.storage.local` on your computer and never leaves it:

- Your settings for each mode (delays, limits, thresholds, keywords, whitelist,
  tweet template, hashtags).
- Live run state and counters (how many actions were performed, last item, status).
- A rolling history of action timestamps — used **only** to enforce your own
  hourly/daily limits. It contains timestamps, not content.
- (Lazada mode only) Lazada API credentials you enter — App Key, App Secret,
  Access Token, Sub/Tracking ID. These are stored locally and used only to sign
  requests sent directly from your browser to the Lazada API.

You can erase all of this at any time by removing the extension or clearing its
storage from `chrome://extensions`.

## What the extension accesses on the web

- **x.com / twitter.com** — the core features read the page you are on and click
  buttons (follow, unfollow, repost, like, delete, post) on your behalf, within
  your own logged-in session. No page content is sent anywhere.
- **api.lazada.co.th / api.lazada.com** — used **only** in Lazada mode, to search
  products and/or generate affiliate links using **your own** API credentials.
  Requests go directly from your browser to Lazada.

## What the extension does NOT do

- It does not collect or transmit your X credentials, cookies, or personal info.
- It does not send any data to the developer or any third party.
- It does not use analytics, advertising, fingerprinting, or remote code.
- It does not read pages other than X (and the Lazada API endpoint in Lazada mode).

## Permissions and why they are needed

- `storage` — save your settings and counters locally.
- `tabs` — check the active tab's URL (to confirm you are on x.com before acting)
  and open short-lived background tabs to read public follower counts.
- Host access to `x.com` / `twitter.com` — run the extension's features on X.
- Host access to `api.lazada.co.th` / `api.lazada.com` — Lazada mode only.

## Your responsibility

This extension automates actions on your own account. Automating activity may
violate the Terms of Service of X and/or Lazada and could lead to account limits
or suspension. Use it on your own accounts and at your own risk.

## Contact

Questions about this policy: suksan.cmu@gmail.com
