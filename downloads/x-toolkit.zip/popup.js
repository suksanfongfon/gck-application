// popup.js — UI ควบคุม 4 โหมด (Unfollow / Follow / Feed / Unrepost)
// สถานะการทำงานแยกตามแท็บ (อ่าน/แสดงของแท็บที่กำลังเปิดอยู่เท่านั้น)

const $ = (id) => document.getElementById(id);

const els = {
  delayMin: $("delayMin"),
  delayMax: $("delayMax"),
  maxCount: $("maxCount"),
  noLimit: $("noLimit"),
  hourlyLimit: $("hourlyLimit"),
  dailyLimit: $("dailyLimit"),
  // unfollow
  nonMutualOnly: $("nonMutualOnly"),
  whitelist: $("whitelist"),
  // follow
  verifiedOnly: $("verifiedOnly"),
  minFollowers: $("minFollowers"),
  bioKeywords: $("bioKeywords"),
  // feed
  repostMinViews: $("repostMinViews"),
  feedMinLikes: $("feedMinLikes"),
  followMinFollowers: $("followMinFollowers"),
  feedLike: $("feedLike"),
  feedVideoOnly: $("feedVideoOnly"),
  feedFollowingOnly: $("feedFollowingOnly"),
  feedThaiOnly: $("feedThaiOnly"),
  feedKeywords: $("feedKeywords"),
  // like
  likeMinViews: $("likeMinViews"),
  likeMinLikes: $("likeMinLikes"),
  likeVideoOnly: $("likeVideoOnly"),
  likeFollowingOnly: $("likeFollowingOnly"),
  likeThaiOnly: $("likeThaiOnly"),
  likeKeywords: $("likeKeywords"),
  // unrepost
  unrepMinComments: $("unrepMinComments"),
  unrepMinLikes: $("unrepMinLikes"),
  unrepMinViews: $("unrepMinViews"),
  unrepMatchAll: $("unrepMatchAll"),
  unrepLang: $("unrepLang"),
  // delete
  delMinComments: $("delMinComments"),
  delMinLikes: $("delMinLikes"),
  delMinViews: $("delMinViews"),
  delMatchAll: $("delMatchAll"),
  delKeywords: $("delKeywords"),
  delOlderThanDays: $("delOlderThanDays"),
  // lazada
  lzKeywords: $("lzKeywords"),
  lzMinSold: $("lzMinSold"),
  lzMinReviews: $("lzMinReviews"),
  lzPerKeyword: $("lzPerKeyword"),
  lzSortBy: $("lzSortBy"),
  lzTemplate: $("lzTemplate"),
  lzHashtags: $("lzHashtags"),
  lzManualList: $("lzManualList"),
  lzApiBase: $("lzApiBase"),
  lzAppKey: $("lzAppKey"),
  lzAppSecret: $("lzAppSecret"),
  lzAccessToken: $("lzAccessToken"),
  lzSearchPath: $("lzSearchPath"),
  lzLinkMode: $("lzLinkMode"),
  lzLinkTemplate: $("lzLinkTemplate"),
  lzLinkPath: $("lzLinkPath"),
  lzSubId: $("lzSubId"),
  // ui
  startBtn: $("startBtn"),
  stopBtn: $("stopBtn"),
  resetBtn: $("resetBtn"),
  statusText: $("statusText"),
  countText: $("countText"),
  countLabel: $("countLabel"),
  lastUser: $("lastUser"),
  statusMsg: $("statusMsg"),
  warn: $("warn"),
  openFollowing: $("openFollowing"),
  panelUnfollow: $("panel-unfollow"),
  panelFollow: $("panel-follow"),
  panelFeed: $("panel-feed"),
  panelLike: $("panel-like"),
  panelUnrepost: $("panel-unrepost"),
  panelDelete: $("panel-delete"),
  panelLazada: $("panel-lazada"),
};

const tabs = document.querySelectorAll(".tab");
const X_HOST = /^https:\/\/(x|twitter)\.com\//;

let currentMode = "unfollow";
let activeTabId = null;
const IDLE_STATE = { running: false, count: 0, lastUser: "", statusMsg: "" };
const stateKey = () => "xufState_" + activeTabId;

// แปลง textarea เป็น array ของบรรทัด (ตัดช่องว่าง, ตัวพิมพ์เล็ก)
function parseLines(text, stripAt) {
  return (text || "")
    .split("\n")
    .map((l) => {
      let v = l.trim();
      if (stripAt) v = v.replace(/^@/, "");
      return v.toLowerCase();
    })
    .filter(Boolean);
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function setRunningUI(running) {
  els.startBtn.disabled = running;
  els.stopBtn.disabled = !running;
  [els.delayMin, els.delayMax, els.maxCount, els.noLimit, els.hourlyLimit, els.dailyLimit,
   els.nonMutualOnly, els.whitelist, els.verifiedOnly, els.minFollowers, els.bioKeywords,
   els.repostMinViews, els.feedMinLikes, els.followMinFollowers, els.feedLike, els.feedVideoOnly,
   els.feedFollowingOnly, els.feedThaiOnly, els.feedKeywords,
   els.likeMinViews, els.likeMinLikes, els.likeVideoOnly, els.likeFollowingOnly, els.likeThaiOnly, els.likeKeywords,
   els.unrepMinComments, els.unrepMinLikes, els.unrepMinViews, els.unrepMatchAll, els.unrepLang,
   els.delMinComments, els.delMinLikes, els.delMinViews, els.delMatchAll,
   els.delKeywords, els.delOlderThanDays,
   els.lzKeywords, els.lzMinSold, els.lzMinReviews, els.lzPerKeyword, els.lzSortBy,
   els.lzTemplate, els.lzHashtags, els.lzManualList, els.lzApiBase, els.lzAppKey,
   els.lzAppSecret, els.lzAccessToken, els.lzSearchPath, els.lzLinkMode,
   els.lzLinkTemplate, els.lzLinkPath, els.lzSubId]
    .forEach((el) => (el.disabled = running));
  tabs.forEach((t) => (t.disabled = running));
  // ถ้าไม่จำกัดจำนวน ให้ปิดช่อง maxCount เสมอ
  if (!running) els.maxCount.disabled = els.noLimit.checked;
  els.statusText.textContent = running ? "กำลังทำงาน…" : "หยุดอยู่";
  els.statusText.className = "badge " + (running ? "running" : "idle");
}

function renderProgress(state) {
  if ("count" in state) els.countText.textContent = state.count ?? 0;
  if ("lastUser" in state)
    els.lastUser.textContent = state.lastUser ? "ล่าสุด: " + state.lastUser : "";
  if ("statusMsg" in state) els.statusMsg.textContent = state.statusMsg || "";
  if ("running" in state) setRunningUI(!!state.running);
}

async function updateWarn() {
  // แจ้งเตือนเฉพาะโหมด unfollow ที่ต้องอยู่หน้า Following
  if (currentMode !== "unfollow") {
    els.warn.classList.add("hidden");
    return;
  }
  const tab = await getActiveTab();
  const onX = tab && X_HOST.test(tab.url || "");
  const onFollowing = onX && /\/following\/?$/.test(new URL(tab.url).pathname);
  els.warn.classList.toggle("hidden", !!onFollowing);
}

function applyMode(mode) {
  currentMode = ["follow", "feed", "like", "unrepost", "delete", "lazada"].includes(mode) ? mode : "unfollow";
  tabs.forEach((t) => t.classList.toggle("active", t.dataset.mode === currentMode));
  els.panelUnfollow.classList.toggle("hidden", currentMode !== "unfollow");
  els.panelFollow.classList.toggle("hidden", currentMode !== "follow");
  els.panelFeed.classList.toggle("hidden", currentMode !== "feed");
  els.panelLike.classList.toggle("hidden", currentMode !== "like");
  els.panelUnrepost.classList.toggle("hidden", currentMode !== "unrepost");
  els.panelDelete.classList.toggle("hidden", currentMode !== "delete");
  els.panelLazada.classList.toggle("hidden", currentMode !== "lazada");

  const labelMap = {
    unfollow: "unfollow แล้ว",
    follow: "follow แล้ว",
    feed: "ดำเนินการแล้ว",
    like: "ไลก์แล้ว",
    unrepost: "ยกเลิกแล้ว",
    delete: "ลบแล้ว",
    lazada: "โพสต์แล้ว",
  };
  const btnMap = {
    unfollow: "▶ Start Unfollow",
    follow: "▶ Start Follow",
    feed: "▶ Start Feed",
    like: "▶ Start Like",
    unrepost: "▶ Start Unrepost",
    delete: "▶ Start Delete",
    lazada: "▶ Start Lazada",
  };
  els.countLabel.textContent = labelMap[currentMode];
  els.startBtn.textContent = btnMap[currentMode];

  chrome.storage.local.set({ mode: currentMode });
  updateWarn();
}

async function init() {
  const saved = await chrome.storage.local.get([
    "delayMin", "delayMax", "maxCount", "noLimit", "hourlyLimit", "dailyLimit",
    "nonMutualOnly", "whitelist",
    "verifiedOnly", "minFollowers", "bioKeywords",
    "repostMinViews", "feedMinLikes", "followMinFollowers", "feedLike", "feedVideoOnly", "feedFollowingOnly", "feedThaiOnly", "feedKeywords",
    "likeMinViews", "likeMinLikes", "likeVideoOnly", "likeFollowingOnly", "likeThaiOnly", "likeKeywords",
    "unrepMinComments", "unrepMinLikes", "unrepMinViews", "unrepMatchAll", "unrepLang",
    "delMinComments", "delMinLikes", "delMinViews", "delMatchAll", "delKeywords", "delOlderThanDays",
    "lzKeywords", "lzMinSold", "lzMinReviews", "lzPerKeyword", "lzSortBy", "lzTemplate", "lzHashtags",
    "lzManualList", "lzApiBase", "lzAppKey", "lzAppSecret", "lzAccessToken", "lzSearchPath",
    "lzLinkMode", "lzLinkTemplate", "lzLinkPath", "lzSubId",
    "mode",
  ]);

  if (saved.delayMin != null) els.delayMin.value = saved.delayMin;
  if (saved.delayMax != null) els.delayMax.value = saved.delayMax;
  if (saved.maxCount != null) els.maxCount.value = saved.maxCount;
  if (saved.noLimit != null) els.noLimit.checked = saved.noLimit;
  els.maxCount.disabled = els.noLimit.checked;
  if (saved.hourlyLimit != null) els.hourlyLimit.value = saved.hourlyLimit;
  if (saved.dailyLimit != null) els.dailyLimit.value = saved.dailyLimit;
  if (saved.nonMutualOnly != null) els.nonMutualOnly.checked = saved.nonMutualOnly;
  if (Array.isArray(saved.whitelist)) els.whitelist.value = saved.whitelist.join("\n");
  if (saved.verifiedOnly != null) els.verifiedOnly.checked = saved.verifiedOnly;
  if (saved.minFollowers != null) els.minFollowers.value = saved.minFollowers;
  if (Array.isArray(saved.bioKeywords)) els.bioKeywords.value = saved.bioKeywords.join("\n");
  if (saved.repostMinViews != null) els.repostMinViews.value = saved.repostMinViews;
  if (saved.feedMinLikes != null) els.feedMinLikes.value = saved.feedMinLikes;
  if (saved.followMinFollowers != null) els.followMinFollowers.value = saved.followMinFollowers;
  if (saved.feedLike != null) els.feedLike.checked = saved.feedLike;
  if (saved.feedVideoOnly != null) els.feedVideoOnly.checked = saved.feedVideoOnly;
  if (saved.feedFollowingOnly != null) els.feedFollowingOnly.checked = saved.feedFollowingOnly;
  if (saved.feedThaiOnly != null) els.feedThaiOnly.checked = saved.feedThaiOnly;
  if (Array.isArray(saved.feedKeywords)) els.feedKeywords.value = saved.feedKeywords.join("\n");
  if (saved.likeMinViews != null) els.likeMinViews.value = saved.likeMinViews;
  if (saved.likeMinLikes != null) els.likeMinLikes.value = saved.likeMinLikes;
  if (saved.likeVideoOnly != null) els.likeVideoOnly.checked = saved.likeVideoOnly;
  if (saved.likeFollowingOnly != null) els.likeFollowingOnly.checked = saved.likeFollowingOnly;
  if (saved.likeThaiOnly != null) els.likeThaiOnly.checked = saved.likeThaiOnly;
  if (Array.isArray(saved.likeKeywords)) els.likeKeywords.value = saved.likeKeywords.join("\n");
  if (saved.unrepMinComments != null) els.unrepMinComments.value = saved.unrepMinComments;
  if (saved.unrepMinLikes != null) els.unrepMinLikes.value = saved.unrepMinLikes;
  if (saved.unrepMinViews != null) els.unrepMinViews.value = saved.unrepMinViews;
  if (saved.unrepMatchAll != null) els.unrepMatchAll.checked = saved.unrepMatchAll;
  if (saved.unrepLang != null) els.unrepLang.value = saved.unrepLang;
  if (saved.delMinComments != null) els.delMinComments.value = saved.delMinComments;
  if (saved.delMinLikes != null) els.delMinLikes.value = saved.delMinLikes;
  if (saved.delMinViews != null) els.delMinViews.value = saved.delMinViews;
  if (saved.delMatchAll != null) els.delMatchAll.checked = saved.delMatchAll;
  if (Array.isArray(saved.delKeywords)) els.delKeywords.value = saved.delKeywords.join("\n");
  if (saved.delOlderThanDays != null) els.delOlderThanDays.value = saved.delOlderThanDays;
  if (Array.isArray(saved.lzKeywords)) els.lzKeywords.value = saved.lzKeywords.join("\n");
  if (saved.lzMinSold != null) els.lzMinSold.value = saved.lzMinSold;
  if (saved.lzMinReviews != null) els.lzMinReviews.value = saved.lzMinReviews;
  if (saved.lzPerKeyword != null) els.lzPerKeyword.value = saved.lzPerKeyword;
  if (saved.lzSortBy != null) els.lzSortBy.value = saved.lzSortBy;
  if (saved.lzTemplate != null) els.lzTemplate.value = saved.lzTemplate;
  if (saved.lzHashtags != null)
    els.lzHashtags.value = Array.isArray(saved.lzHashtags) ? saved.lzHashtags.join(" ") : saved.lzHashtags;
  if (saved.lzManualList != null) els.lzManualList.value = saved.lzManualList;
  if (saved.lzApiBase != null) els.lzApiBase.value = saved.lzApiBase;
  if (saved.lzAppKey != null) els.lzAppKey.value = saved.lzAppKey;
  if (saved.lzAppSecret != null) els.lzAppSecret.value = saved.lzAppSecret;
  if (saved.lzAccessToken != null) els.lzAccessToken.value = saved.lzAccessToken;
  if (saved.lzSearchPath != null) els.lzSearchPath.value = saved.lzSearchPath;
  if (saved.lzLinkMode != null) els.lzLinkMode.value = saved.lzLinkMode;
  if (saved.lzLinkTemplate != null) els.lzLinkTemplate.value = saved.lzLinkTemplate;
  if (saved.lzLinkPath != null) els.lzLinkPath.value = saved.lzLinkPath;
  if (saved.lzSubId != null) els.lzSubId.value = saved.lzSubId;

  applyMode(saved.mode || "unfollow");

  // อ่านสถานะของ "แท็บที่กำลังเปิดอยู่" เท่านั้น (แต่ละแท็บมี state แยกกัน)
  const tab = await getActiveTab();
  activeTabId = tab ? tab.id : null;
  let st = null;
  if (activeTabId != null) {
    st = (await chrome.storage.local.get(stateKey()))[stateKey()];
  }
  renderProgress(st || IDLE_STATE);
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || activeTabId == null) return;
  if (changes[stateKey()]) {
    renderProgress(changes[stateKey()].newValue || IDLE_STATE);
  }
});

tabs.forEach((t) => t.addEventListener("click", () => applyMode(t.dataset.mode)));

els.noLimit.addEventListener("change", () => {
  els.maxCount.disabled = els.noLimit.checked;
  chrome.storage.local.set({ noLimit: els.noLimit.checked });
});

els.startBtn.addEventListener("click", async () => {
  const settings = {
    mode: currentMode,
    delayMin: Math.max(1, parseInt(els.delayMin.value, 10) || 4),
    delayMax: Math.max(1, parseInt(els.delayMax.value, 10) || 9),
    maxCount: els.noLimit.checked ? 0 : Math.max(1, parseInt(els.maxCount.value, 10) || 50),
    hourlyLimit: Math.max(0, parseInt(els.hourlyLimit.value, 10) || 0),
    dailyLimit: Math.max(0, parseInt(els.dailyLimit.value, 10) || 0),
    // unfollow
    nonMutualOnly: els.nonMutualOnly.checked,
    whitelist: parseLines(els.whitelist.value, true),
    // follow
    verifiedOnly: els.verifiedOnly.checked,
    minFollowers: Math.max(0, parseInt(els.minFollowers.value, 10) || 0),
    bioKeywords: parseLines(els.bioKeywords.value, false),
    // feed
    repostMinViews: Math.max(0, parseInt(els.repostMinViews.value, 10) || 0),
    feedMinLikes: Math.max(0, parseInt(els.feedMinLikes.value, 10) || 0),
    followMinFollowers: Math.max(0, parseInt(els.followMinFollowers.value, 10) || 0),
    feedLike: els.feedLike.checked,
    feedVideoOnly: els.feedVideoOnly.checked,
    feedFollowingOnly: els.feedFollowingOnly.checked,
    feedThaiOnly: els.feedThaiOnly.checked,
    feedKeywords: parseLines(els.feedKeywords.value, false),
    // like
    likeMinViews: Math.max(0, parseInt(els.likeMinViews.value, 10) || 0),
    likeMinLikes: Math.max(0, parseInt(els.likeMinLikes.value, 10) || 0),
    likeVideoOnly: els.likeVideoOnly.checked,
    likeFollowingOnly: els.likeFollowingOnly.checked,
    likeThaiOnly: els.likeThaiOnly.checked,
    likeKeywords: parseLines(els.likeKeywords.value, false),
    // unrepost
    unrepMinComments: Math.max(0, parseInt(els.unrepMinComments.value, 10) || 0),
    unrepMinLikes: Math.max(0, parseInt(els.unrepMinLikes.value, 10) || 0),
    unrepMinViews: Math.max(0, parseInt(els.unrepMinViews.value, 10) || 0),
    unrepMatchAll: els.unrepMatchAll.checked,
    unrepLang: els.unrepLang.value || "all",
    // delete
    delMinComments: Math.max(0, parseInt(els.delMinComments.value, 10) || 0),
    delMinLikes: Math.max(0, parseInt(els.delMinLikes.value, 10) || 0),
    delMinViews: Math.max(0, parseInt(els.delMinViews.value, 10) || 0),
    delMatchAll: els.delMatchAll.checked,
    delKeywords: parseLines(els.delKeywords.value, false),
    delOlderThanDays: Math.max(0, parseInt(els.delOlderThanDays.value, 10) || 0),
    // lazada (คำค้น/แมนนวลคงตัวพิมพ์เดิม ไม่ lowercase)
    lzKeywords: (els.lzKeywords.value || "").split("\n").map((l) => l.trim()).filter(Boolean),
    lzMinSold: Math.max(0, parseInt(els.lzMinSold.value, 10) || 0),
    lzMinReviews: Math.max(0, parseInt(els.lzMinReviews.value, 10) || 0),
    lzPerKeyword: Math.max(1, parseInt(els.lzPerKeyword.value, 10) || 20),
    lzSortBy: els.lzSortBy.value || "sold",
    lzTemplate: els.lzTemplate.value || "",
    lzHashtags: els.lzHashtags.value || "",
    lzManualList: els.lzManualList.value || "",
    lzApiBase: (els.lzApiBase.value || "").trim(),
    lzAppKey: (els.lzAppKey.value || "").trim(),
    lzAppSecret: (els.lzAppSecret.value || "").trim(),
    lzAccessToken: (els.lzAccessToken.value || "").trim(),
    lzSearchPath: (els.lzSearchPath.value || "").trim(),
    lzLinkMode: els.lzLinkMode.value || "template",
    lzLinkTemplate: els.lzLinkTemplate.value || "{rawurl}",
    lzLinkPath: (els.lzLinkPath.value || "").trim(),
    lzSubId: (els.lzSubId.value || "").trim(),
  };
  if (settings.delayMax < settings.delayMin) {
    settings.delayMax = settings.delayMin;
    els.delayMax.value = settings.delayMin;
  }

  await chrome.storage.local.set(settings);

  const tab = await getActiveTab();
  if (!tab || !X_HOST.test(tab.url || "")) {
    els.warn.classList.remove("hidden");
    els.statusMsg.textContent = "เปิดหน้า x.com ก่อนนะครับ";
    return;
  }

  try {
    const res = await chrome.tabs.sendMessage(tab.id, { type: "START", settings });
    if (!res || !res.ok) {
      if (res && res.reason === "not-following-page") els.warn.classList.remove("hidden");
      return;
    }
    els.warn.classList.add("hidden");
    setRunningUI(true);
  } catch (e) {
    els.statusMsg.textContent = "โหลดหน้า x.com ใหม่แล้วลองอีกครั้ง";
    els.warn.classList.remove("hidden");
  }
});

els.stopBtn.addEventListener("click", async () => {
  const tab = await getActiveTab();
  if (tab) {
    try {
      await chrome.tabs.sendMessage(tab.id, { type: "STOP" });
    } catch (e) {
      /* ignore */
    }
  }
  setRunningUI(false); // content จะอัปเดต state ของแท็บนี้เองตอน loop จบ
});

els.resetBtn.addEventListener("click", async () => {
  if (activeTabId == null) return;
  const cleared = { ...IDLE_STATE, mode: currentMode };
  await chrome.storage.local.set({ [stateKey()]: cleared });
  renderProgress(cleared);
});

els.openFollowing.addEventListener("click", async () => {
  await chrome.tabs.create({ url: "https://x.com/home" });
});

document.addEventListener("DOMContentLoaded", init);
init();
